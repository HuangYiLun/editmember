

public class UserTag extends Tag {
	private int userTagId;
	private int userId;

	public UserTag(int userTagId, int userId, int id, String name, Category c) {
		super(id, name, c);
		this.userTagId = userTagId;
		this.userId = userId;
	}

	public int getUserTagId() {
		return userTagId;
	}

	public void setUserTagId(int userTagId) {
		this.userTagId = userTagId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

}
