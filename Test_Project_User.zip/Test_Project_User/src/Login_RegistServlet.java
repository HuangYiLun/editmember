
import java.io.BufferedReader;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;



@WebServlet("/Login_RegistServlet")
public class Login_RegistServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private final static String CONTENT_TYPE = "text/html; charset=UTF-8";
	private IUserDao userDao = UserDaoImpl.getInstance();
	private ICompanyDao icompanyDao = CompanyDaoImpl.getInstance();
    @Override
    public void init() throws ServletException {
    	// TODO Auto-generated method stub
    	super.init();
//    	String email= "wk6666@yahoo.com";
//    	String password ="33333";
//    	userDao.register(email, password);
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

//		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
		BufferedReader br = request.getReader();
		StringBuilder jsonIn = new StringBuilder();
		String line = null;
		while ((line = br.readLine()) != null) {
			jsonIn.append(line);
		}
		JsonObject jsonObject = gson.fromJson(jsonIn.toString(), JsonObject.class);

//		UserDao userDao = new UserDaoMySqlImp();
		
		
		String action = jsonObject.get("action").getAsString();
		System.out.println("action: " + action);
		String text = "";
		System.out.println("input:"+jsonIn);
		switch (action) {
//		case "userExist":
//			String email = jsonObject.get("email").getAsString();
//			String password = jsonObject.get("password").getAsString();
//			System.out.println("email: " + email + "; password: " + password);
//			writeText(response, String.valueOf(userDao.userExist(email, password)));
//			break;
		case "login":
			String email = jsonObject.get("email").getAsString();
			String password = jsonObject.get("password").getAsString();
			System.out.println("email: " + email + "; password: " + password);
		  
			writeText(response, gson.toJson(userDao.login(email, password)));
			break;
			
		case "register":
			User user = gson.fromJson(jsonObject.get("user").getAsString(), User.class);
			writeText(response,  gson.toJson(userDao.register(user)));	
			break;
			
		case "update":
			User u = gson.fromJson(jsonObject.get("user").getAsString(), User.class);
			System.out.println(jsonObject.get("user").getAsString());
			writeText(response,  gson.toJson(userDao.update(u)));	
			break;

//		case "insert":
//			User user = gson.fromJson(jsonObject.get("user").getAsString(), User.class);
//			writeText(response, String.valueOf(userDao.insert(user)));
//
//			break;
		case "findUserById":
			int userid = Integer.valueOf(jsonObject.get("userId").getAsString());
			writeText(response,  gson.toJson(userDao.findUserById(userid)));	
			break;
			
		case "getCompanyById":
			int uid = Integer.valueOf(jsonObject.get("userId").getAsString());
			writeText(response,  gson.toJson(userDao.getCompanyByUId(uid)));	
			break;
		case "insertCompany":
			int un = Integer.valueOf(jsonObject.get("UN").getAsString());
			writeText(response,  gson.toJson(icompanyDao.insertCompany(un)));	
			break;
		case "searchCompany":
			int UN = Integer.valueOf(jsonObject.get("UN").getAsString());
			writeText(response,  gson.toJson(icompanyDao.searchCompany(UN)));	
			break;
			
		case "searchCompanyByUN":
			int uns = Integer.valueOf(jsonObject.get("UN").getAsString());
			writeText(response,  gson.toJson(icompanyDao.searchCompanyByUN(uns)));	
			break;
		case "findCapacitiesByUId":
			int userId = Integer.valueOf(jsonObject.get("userId").getAsString());
			writeText(response,  gson.toJson(userDao.findCapacitiesByUId(userId)));	
			break;
			
		case "findExpsByUId":
			int usId = Integer.valueOf(jsonObject.get("userId").getAsString());
			writeText(response,  gson.toJson(userDao.findExpsByUId(usId)));	
			break;
			
		case "updateCompany":
			UserCompany uc = gson.fromJson(jsonObject.get("userCompany").getAsString(), UserCompany.class);
			writeText(response,  gson.toJson(userDao.updateCompany(uc)));	
			
			break;
			
		case "findUserPhone":
			int ud = jsonObject.get("userId").getAsInt();
			writeText(response,  userDao.findUserPhone(ud));	
			break;
			
		case "updateUserPhone":
			String phoneNumber = jsonObject.get("phoneNumber").getAsString();
			int id = Integer.valueOf(jsonObject.get("userId").getAsString());
			System.out.println("id: " + id + "; phoneNumber: " + phoneNumber);
			writeText(response, String.valueOf(userDao.updateUserPhone(id, phoneNumber)));
			break;
			
		case "getImgByPath":
			OutputStream os = response.getOutputStream();
			String path = jsonObject.get("path").getAsString();
			byte[] image = userDao.getImgByPath(path);
			if (image != null) {
				response.setContentType("image/jpeg");
				response.setContentLength(image.length);
			}
			os.write(image);
			break;
			
			
			
//		case "userEmailExist":
//		      String Remail = jsonObject.get("email").getAsString();
//		      System.out.println("email:"+ Remail);
//		      writeText(response, String.valueOf(userDao.userEmailExist(Remail)));
//             break;
		default:
			break;
		}

	}

	private void writeText(HttpServletResponse response, String text) throws IOException {
		System.out.println("output:" + text);
		response.setCharacterEncoding("UTF-8");
		response.getWriter().write(text);

	}

}
