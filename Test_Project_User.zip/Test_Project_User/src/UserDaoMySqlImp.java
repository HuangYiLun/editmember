import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class UserDaoMySqlImp implements UserDao {
	public UserDaoMySqlImp() {
		super();
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	@Override
	public User userExist(String email, String password) {
		User user = null;
		String sql = "SELECT user_id FROM user_account WHERE email = ? AND password = ?;";
		Connection conn = null;
		PreparedStatement ps = null;
		
		try {
			conn = DriverManager.getConnection(Common.URL, Common.USER, Common.PASSWORD);
			ps = conn.prepareStatement(sql);
			ps.setString(1, email);
			ps.setString(2, password);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				int userId = rs.getInt(1);
//				user = new User(userId);
			}
			return user;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return user;
	}

	@Override
	public int insert(User user) {
		String sql = "INSERT INTO user_account(email, password, user_name, user_gender) " + "VALUES(?, ?, ?, ?);";
		Connection conn = null;
		PreparedStatement ps = null;
		int count = 0;

		try {
			conn = DriverManager.getConnection(Common.URL, Common.USER, Common.PASSWORD);
			ps = conn.prepareStatement(sql);
			ps.setString(1, user.getEmail());
			ps.setString(2, user.getPassword());
//			ps.setString(3, user.getName());
//			ps.setInt(4, user.getGender());
			count = ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return count;
	}

	@Override
	public int update(User user ) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public User findByEM(String email) {

		return null;
	}

	@Override
	public boolean userEmailExist(String email) {
		String sql = "SELECT email FROM user_account WHERE email = ?;";
		Connection conn = null;
		PreparedStatement ps = null;
		boolean isUserEmailExist = false;
		try {
			conn = DriverManager.getConnection(Common.URL, Common.USER,
					Common.PASSWORD);
			ps = conn.prepareStatement(sql);
			ps.setString(1, email);
			ResultSet rs = ps.executeQuery();
			isUserEmailExist = rs.next();
			return isUserEmailExist;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return isUserEmailExist;
	}
		

}
