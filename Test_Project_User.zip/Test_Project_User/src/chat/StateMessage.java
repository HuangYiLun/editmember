package chat;

import java.util.Set;

public class StateMessage {
	private String type;
	private String userID;
	private Set<String> userIDs;
	public StateMessage(String type, String userID,Set<String> userIDs) {
		super();
		this.type = type;
		this.userID = userID;
		this.userIDs = userIDs;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public Set<String> getUserIDs() {
		return userIDs;
	}
	public void setUserIDs(Set<String> userIDs) {
		this.userIDs = userIDs;
	}
	

}
