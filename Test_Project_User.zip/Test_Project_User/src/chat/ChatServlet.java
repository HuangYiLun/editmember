package chat;

import java.nio.ByteBuffer;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import javax.websocket.CloseReason;
import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;
import com.google.gson.Gson;



@ServerEndpoint("/ChatServlet/{userID}")
public class ChatServlet {
	private TrackDaoImpl trackDaoImpl;
//userEmail
	private static Map<String, Session> sessionMap = new ConcurrentHashMap<>();
	Gson gson = new Gson();

	@OnOpen // 使用者成功連線後 呼叫
	public void onOpen(@PathParam("userID") String userID, Session userSession) {
//		int ud =Integer.valueOf(userID);
//		List<User> trackfriends=trackDaoImpl.findTrackedUsersByUId(ud);
//		Set<String> trackId = new HashSet<String>();
//		for(User friend :trackfriends) {
//			trackId.add(String.valueOf(friend.getUserId()));
//			System.out.println("trackId"+String.valueOf(friend.getUserId()));
//		}
		int maxBufferSize = 500 * 1024;
		userSession.setMaxTextMessageBufferSize(maxBufferSize);
		userSession.setMaxBinaryMessageBufferSize(maxBufferSize);
		// 將有連線的user 存入
		sessionMap.put(userID, userSession);
		// 連資料庫 拿 tracking_user_id

		Set<String> userIDs = sessionMap.keySet();
		StateMessage stateMessage = new StateMessage("open",userID,userIDs);
		String stateMessageJson = gson.toJson(stateMessage);
		Collection<Session> sessions = sessionMap.values();
		// 告訴朋友 上線
		for (Session session : sessions) {
			session.getAsyncRemote().sendText(stateMessageJson);
			System.out.println("out"+stateMessageJson+","+session.getId());
		}

		String text = String.format("Session ID = %s, connected; userEmail = %s%nuserEmails: %s%nmaxTextMessageBufferSize = %s",
				userSession.getId(), userID, userIDs, userSession.getMaxTextMessageBufferSize());
		System.out.println(text);
	}

	// 收到client端傳上來的string message
	@OnMessage
	public void onMessage(Session userSession, String message) {
		System.out.println("message received:" + message);
		ChatMessage chatMessage = gson.fromJson(message, ChatMessage.class);
		String messageType = chatMessage.getMessageType();
		System.out.println("messageType = " + messageType);
		String receiver_em = chatMessage.getReceiver_ID();
		Session receiverSession = sessionMap.get(receiver_em);
		if (receiverSession != null && receiverSession.isOpen()) {
			if (messageType.equals("image")) {
				int imageLength = chatMessage.getContent().getBytes().length;
				System.out.println("image length:" + imageLength);
				receiverSession.getAsyncRemote().sendBinary(ByteBuffer.wrap(message.getBytes()));
			} else {
				receiverSession.getAsyncRemote().sendText(message);
			}
		}
	}

	@OnMessage
	public void onMessage(Session userSession, ByteBuffer bytes) {
		String message = new String(bytes.array());
		System.out.println("ByteBuffer Message received: " + message);
	}

	@OnError
	public void onError(Session userSession, Throwable e) {
		System.out.println("Error: " + e.toString());
	}

	@OnClose
	public void onclose(Session userSession, CloseReason reason) {
		String userIDClose = null;
		Set<String> userIDs = sessionMap.keySet();
		for (String userID : userIDs) {
			if (sessionMap.get(userID).equals(userSession)) {
				userIDClose = userID;
				sessionMap.remove(userID);
				break;
			}
		}
		if (userIDClose != null) {
			StateMessage stateMessage = new StateMessage("close", userIDClose,userIDs);
			String stateMessageJson = gson.toJson(stateMessage);
			Collection<Session> sessions = sessionMap.values();
			for (Session session : sessions) {
				session.getAsyncRemote().sendText(stateMessageJson);
			}
		}
		
		String text = String.format("session ID = %s, disconnected; close code = %d%nusers: %s", userSession.getId(),
				reason.getCloseCode().getCode(), userIDs);
		System.out.println(text);
	}
	
	

}
