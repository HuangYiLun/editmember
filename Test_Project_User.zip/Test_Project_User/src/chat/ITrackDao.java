package chat;



import java.util.List;

public interface ITrackDao {
	
	
	//onInsert column
	int trackUser(User tracker,User trackedU);
	int trackCase(User tracker,Case trackedC);
	
	
	//onDelete column
	int unTrackUser(User tracker,User trackedU);
	int unTrackCase(User tracker,Case trackedC);
	
	//get user's tracks
	List<User> findTrackedUsersByUId(int uid);
	List<Case> findTrackedCasesByUId(int uid);
	

}
