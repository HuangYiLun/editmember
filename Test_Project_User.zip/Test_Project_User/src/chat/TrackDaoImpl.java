package chat;





import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TrackDaoImpl implements ITrackDao {

	private static final String TAG = "TrackDaoImpl";

	@Override
	public int trackUser(User tracker, User trackedU) {
		int count = 0;
		String sql = "IF(SELECT COUNT(*) FROM user_track_user WHERE user_id=? AND case_id=?;) = 0"
				+ "INSERT INTO user_track_user(user_id,tracking_user_id) VALUES(?,?);" + "END IF;";
		Connection con = null;
		java.sql.PreparedStatement pps = null;

		try {
			con = DBCP.getDatasource().getConnection();
			pps = con.prepareStatement(sql);
			pps.setInt(1, tracker.getUserId());
			pps.setInt(2, trackedU.getUserId());
			pps.setInt(3, tracker.getUserId());
			pps.setInt(4, trackedU.getUserId());
			count = pps.executeUpdate();
		} catch (SQLException e) {
			System.out.println(TAG + "TRACK USER" + e.toString());
		} finally {
			try {
				if (con != null) {
					con.close();
				}
				if (pps != null) {
					pps.close();
				}
			} catch (SQLException e) {
				System.out.println(TAG + "close " + e.toString());
			}
		}
		return count;
	}

	@Override
	public int trackCase(User tracker, Case trackedC) {
		int count = 0;
		String sql = "IF(SELECT COUNT(*) FROM user_track_case WHERE user_id=? AND case_id=?;) = 0"
				+ "INSERT INTO user_track_case(user_id,case_id) VALUES(?,?);" + "END IF;";
		Connection con = null;
		java.sql.PreparedStatement pps = null;
		try {
			con = DBCP.getDatasource().getConnection();
			pps = con.prepareStatement(sql);
			pps.setInt(1, tracker.getUserId());
			pps.setInt(2, trackedC.getCaseId());
			pps.setInt(3, tracker.getUserId());
			pps.setInt(4, trackedC.getCaseId());
			count = pps.executeUpdate();
		} catch (SQLException e) {
			System.out.println(TAG + "TRACK CASE" + e.toString());
		} finally {
			try {
				if (con != null) {
					con.close();
				}
				if (pps != null) {
					pps.close();
				}
			} catch (SQLException e) {
				System.out.println(TAG + "close " + e.toString());
			}
		}
		return count;
	}

	@Override
	public int unTrackUser(User tracker, User trackedU) {
		int count = 0;
		String sql = "DELETE FROM user_track_user WHERE user_id=? AND tracking_user_id=?;";
		Connection con = null;
		java.sql.PreparedStatement pps = null;
		try {
			con = DBCP.getDatasource().getConnection();
			pps = con.prepareStatement(sql);
			pps.setInt(1, tracker.getUserId());
			pps.setInt(2, trackedU.getUserId());
			count = pps.executeUpdate();
		} catch (SQLException e) {
			System.out.println(TAG + "UNTRACK USER" + e.toString());
		} finally {
			try {
				if (con != null) {
					con.close();
				}
				if (pps != null) {
					pps.close();
				}
			} catch (SQLException e) {
				System.out.println(TAG + "close " + e.toString());
			}
		}

		return count;
	}

	@Override
	public int unTrackCase(User tracker, Case trackedC) {
		int count = 0;
		String sql = "DELETE FROM user_track_case WHERE user_id=? AND case_id=?;";
		Connection con = null;
		java.sql.PreparedStatement pps = null;
		try {
			con = DBCP.getDatasource().getConnection();
			pps = con.prepareStatement(sql);
			pps.setInt(1, tracker.getUserId());
			pps.setInt(2, trackedC.getCaseId());
			count = pps.executeUpdate();
		} catch (SQLException e) {
			System.out.println(TAG + "UNTRACK CASE" + e.toString());
		} finally {
			try {
				if (con != null) {
					con.close();
				}
				if (pps != null) {
					pps.close();
				}
			} catch (SQLException e) {
				System.out.println(TAG + "close " + e.toString());
			}
		}
		return count;
	}

	@Override
	public List<User> findTrackedUsersByUId(int uid) {
		List<User> users = new ArrayList<>();
		String sql = "SELECT user_account.* FROM user_account RIGHT JOIN user_track_user ON user_account.user_id = user_track_user.user_id"
				+ "WHERE user_id = ?;";
		Connection con = null;
		java.sql.PreparedStatement pps = null;
		try {
			con = DBCP.getDatasource().getConnection();
			pps = con.prepareStatement(sql);
			pps.setInt(1, uid);
			ResultSet rs = pps.executeQuery();
			while (rs.next()) {
				int userId = rs.getInt(1);
				String email = rs.getString(2);
				// String password =rs.getString(3);//skipped
				Date registerTime = rs.getDate(4);
				boolean isFBRegistered = rs.getBoolean(5);
				String userName = rs.getString(6);
				String userLINE = rs.getString(7);
				String userSelfDes = rs.getString(8);
				boolean userGender = rs.getBoolean(9);
				String userPicPath = rs.getString(10);

				User user = new User(userId, email, registerTime, isFBRegistered, userName, userLINE, userSelfDes,
						userGender, userPicPath);
				users.add(user);
			}
		} catch (SQLException e) {
			System.out.println(TAG + "FIND TRACK USER BY UID" + e.toString());
		} finally {
			try {
				if (con != null) {
					con.close();
				}
				if (pps != null) {
					pps.close();
				}
			} catch (SQLException e) {
				System.out.println(TAG + "close " + e.toString());
			}
		}
		return users;
	}

	@Override
	public List<Case> findTrackedCasesByUId(int uid) {
		List<Case> cases = new ArrayList<>();
		String sql = "SELECT user_case_basic.* FROM user_case_basic RIGHT JOIN user_track_case ON user_case_basic.case_id=user_track_case.case_id "
				+ "WHERE user_id = ?;";
		Connection con = null;
		java.sql.PreparedStatement pps = null;
		try {
			con = DBCP.getDatasource().getConnection();
			pps = con.prepareStatement(sql);
			pps.setInt(1, uid);
			ResultSet rs = pps.executeQuery();
			while (rs.next()) {
				int caseId = rs.getInt(1);
				String caseName = rs.getString(2);
				Date caseRecruitStart = rs.getDate(3);
				Date caseRecruitEndrs = rs.getDate(4);
				int caseRecruitProgress = rs.getInt(5);
				Date caseWorkStart = rs.getDate(6);
				Date caseWorkEnd = rs.getDate(7);
				int caseMemberCount = rs.getInt(8);
				int casePayMin = rs.getInt(9);
				int casePayMax = rs.getInt(10);
				int caseOwnerId = rs.getInt(11);
				String caseDes = rs.getString(12);/// wrong sort must fix

				Case ca = new Case(caseId, caseName, caseRecruitStart, caseRecruitEndrs, caseRecruitProgress,
						caseWorkStart, caseWorkEnd, caseMemberCount, casePayMin, casePayMax, caseOwnerId, caseDes);
				cases.add(ca);
			}

		} catch (SQLException e) {
			System.out.println(TAG + "FIND TRACK CASE BY UID" + e.toString());
		} finally {
			try {
				if (con != null) {
					con.close();
				}
				if (pps != null) {
					pps.close();
				}
			} catch (SQLException e) {
				System.out.println(TAG + "close " + e.toString());
			}
		}

		return cases;
	}

}
