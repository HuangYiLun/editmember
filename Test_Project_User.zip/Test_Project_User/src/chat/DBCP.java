package chat;

import org.apache.tomcat.jdbc.pool.DataSource;
import org.apache.tomcat.jdbc.pool.PoolProperties;

public class DBCP {

	private static DataSource datasource = new DataSource();
	private static PoolProperties p = new PoolProperties();
	private static DBCP instance = new DBCP();

	//
	private static final String TAG = "DBCP : ";

	private static final String DB = "show";
	private static final String DRIVER = "com.mysql.jdbc.Driver";
	private static final String ROOT = "root";
	private static final String ROOT_PASSWORD = "root";
	private static final String DBC = "jdbc:mysql://localhost:3306/" + DB + "?useUnicode=true&characterEncoding=UTF8";

	private DBCP() {
		p.setUrl(DBC);
		p.setDriverClassName(DRIVER);
		p.setUsername(ROOT);
		p.setPassword(ROOT_PASSWORD);
		p.setJmxEnabled(true);
		p.setTestWhileIdle(false);
		p.setTestOnBorrow(true);
		p.setValidationQuery("SELECT 1");
		p.setTestOnReturn(false);
		p.setValidationInterval(30000);
		p.setTimeBetweenEvictionRunsMillis(30000);
		p.setMaxActive(7);
		p.setInitialSize(5);
		p.setMaxWait(-1);
		p.setRemoveAbandonedTimeout(60);
		p.setMinEvictableIdleTimeMillis(30000);
		p.setMinIdle(7);
		p.setLogAbandoned(true);
		p.setRemoveAbandoned(true);
		p.setJdbcInterceptors("org.apache.tomcat.jdbc.pool.interceptor.ConnectionState;"
				+ "org.apache.tomcat.jdbc.pool.interceptor.StatementFinalizer");
		datasource.setPoolProperties(p);
		System.out.println(TAG + " Initialize end");
	}

	public static DataSource getDatasource() {
		return datasource;
	}

}
