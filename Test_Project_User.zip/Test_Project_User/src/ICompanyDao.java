

public interface ICompanyDao {
	
	int insertCompany(int UN);
	Company searchCompany(int UN);

}
