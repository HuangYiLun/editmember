import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;



public class UserDaoImpl implements IUserDao {

	private static final String TAG = "UserDao : ";
	private static UserDaoImpl instance = new UserDaoImpl();
	private static final String IMG_DIR = "Users/huangyilun/Desktop/profile/";

	private UserDaoImpl() {
	}

	public static UserDaoImpl getInstance() {
		return instance;
	}

	@Override
	public int register(User user) {
		int count = 0;
//		String sql = "IF(SELECT COUNT(*) FROM user_account WHERE email = ?;) = 0 INSERT INTO user_account(email,password,user_name,user_gender) VALUES(?,SHA1(?),?,?); " + "ENDIF";
//		String sql = "INSERT INTO user_account(email, password,,user_pic_path, user_name, user_gender) " + "VALUES(?, SHA1(?), ?, ?,?);";
		String sql = "INSERT INTO user_account(email,password,user_pic_path,user_name,user_gender) SELECT ?,SHA(?),?,? FROM user_account WHERE NOT EXISTS(SELECT email FROM user_account WHERE email = ?) LIMIT 1";
		Connection con = null;
		java.sql.PreparedStatement pps = null;
		Pattern pattern = Pattern.compile("^[_a-z0-9-]+([.][_a-z0-9-]+)*@[a-z0-9-]+([.][a-z0-9-]+)*$");
//		Matcher matcher = pattern.matcher(email);
		Matcher matcher = pattern.matcher(user.getEmail());
		if (matcher.matches()) {
			try {
				con = DBCP.getDatasource().getConnection();
				pps = con.prepareStatement(sql);
				long date = Calendar.getInstance().getTimeInMillis();
				String path = "U" + date + "PIC"+".jpg";
				pps.setString(1, user.getEmail());
//				pps.setString(2, user.getEmail());
				pps.setString(2, user.getPassword());
				pps.setString(3, path);
				pps.setString(4, user.getUserName());
				pps.setBoolean(5, user.isUserGender());
				count = pps.executeUpdate();
			} catch (SQLException e) {
				System.out.println(TAG + "REGISTER " + e.toString());
			} finally {
				try {
					if (con != null) {
						con.close();
					}
					if (pps != null) {
						pps.close();
					}
				} catch (SQLException e) {

					System.out.println(TAG + "close " + e.toString());
				}
			}
		}
		return count;
	}

	@Override
	public User login(String email, String password) {
		User user = null;
		String sql = "SELECT user_id,register_time,facebook_registered,user_name,"
				+ "user_LINE,user_self_description,user_gender,user_pic_path "
				+ "FROM user_account WHERE email = ? AND password = SHA1(?);";
		Connection con = null;
		java.sql.PreparedStatement pps = null;
		try {
			con = DBCP.getDatasource().getConnection();
			pps = con.prepareStatement(sql);
			pps.setString(1, email);
			pps.setString(2, password);
			ResultSet rs = pps.executeQuery();
			if (rs.next()) {
				int userId = rs.getInt(1);
				Date registerTime = rs.getDate(2);
				boolean isFBRegistered = rs.getBoolean(3);
				String userName = rs.getString(4);
				String userLINE = rs.getString(5);
				String userSelfDes = rs.getString(6);
				boolean userGender = rs.getBoolean(7);
				String userPicPath = rs.getString(8);
				user = new User(userId, email, registerTime, isFBRegistered, userName, userLINE, userSelfDes,
						userGender, userPicPath);
			}
		} catch (SQLException e) {
			System.out.println(TAG + "REGISTER " + e.toString());
		} finally {
			try {
				if (con != null) {
					con.close();
				}
				if (pps != null) {
					pps.close();
				}
			} catch (SQLException e) {
				System.out.println(TAG + "close " + e.toString());
			}
		}
		return user;
	}

	@Override
	//改
	public int update(User u) {
		int count = 0;
//		String sql = "UPDATE user_account SET password = SHA1(?),user_name=?,user_LINE=?,user_self_description=?,user_gender=? "
//				+ "WHERE user_id=? AND email=?;";
		String sql = "UPDATE user_account SET user_name=?,user_LINE=?,user_self_description=?,user_gender=?,live=? "
				+ "WHERE user_id=?;";
		Connection con = null;
		java.sql.PreparedStatement pps = null;

		try {
			con = DBCP.getDatasource().getConnection();
			pps = con.prepareStatement(sql);
//			pps.setString(1, u.getPassword());
			pps.setString(1, u.getUserName());
			pps.setString(2, u.getUserLINE());
			pps.setString(3, u.getUserSelfDes());
			pps.setBoolean(4, u.isUserGender());
			pps.setString(5, u.getUserlive());
			pps.setInt(6, u.getUserId());
			
//			pps.setString(7, u.getEmail());
			count = pps.executeUpdate();
		} catch (SQLException e) {
			System.out.println(TAG + "UPDATE " + e.toString());
		} finally {
			try {
				if (con != null) {
					con.close();
				}
				if (pps != null) {
					pps.close();
				}
			} catch (SQLException e) {
				System.out.println(TAG + "close " + e.toString());
			}
		}
		return count;
	}

	@Override
	public int UpdateUserPic(byte[] pic, String path) {
		int count = 0;
		FileOutputStream fo = null;
		try {
			File file = new File(IMG_DIR + path);
			if (file.exists()) {
				file.delete();
			}
			fo = new FileOutputStream(IMG_DIR + path);
			fo.write(pic);

		} catch (FileNotFoundException e) {
			System.out.println(TAG + "FILE " + e.toString());
		} catch (IOException e) {
			System.out.println(TAG + "IO" + e.toString());
		} finally {
			try {
				if (fo != null) {
					fo.close();
				}
			} catch (IOException e) {
				System.out.println(TAG + "close " + e.toString());
			}
		}
		return count;
	}

	@Override
	public byte[] getUserPicByPath(String path) {
		byte[] pic = null;
		try {
			pic = Files.readAllBytes(new File(IMG_DIR + path).toPath());
		} catch (IOException e) {
			System.out.println(TAG + "GET PIC BY Path " + e.toString());
		}
		return pic;
	}

	@Override
	public int updateCompany(UserCompany uc) {
		int count = 0;
		String sql = "INSERT INTO user_company(user_company_id,user_id,company_id,company_name) VALUES(?,?,?,?) "
				+ "ON DUPLICATE KEY UPDATE company_id =?,company_name = ? ;";
		Connection con = null;
		java.sql.PreparedStatement pps = null;
		try {
			con = DBCP.getDatasource().getConnection();
			pps = con.prepareStatement(sql);
			pps.setInt(1, uc.getUserCompanyId());
			pps.setInt(2, uc.getUserId());
			pps.setInt(3, uc.getCompanyId());
			pps.setInt(4, uc.getCompanyId());
			pps.setString(5, uc.getName());
			count = pps.executeUpdate();
		} catch (SQLException e) {
			System.out.println(TAG + "UPDATE COMPANY " + e.toString());
		} finally {
			try {
				if (con != null) {
					con.close();
				}
				if (pps != null) {
					pps.close();
				}
			} catch (SQLException e) {
				System.out.println(TAG + "close " + e.toString());
			}
		}
		return count;
	}

	@Override
	public int insertUserCapacity(int uid, Category c) {
		int count = 0;
		String sql = "INSERT INTO user_capacity(user_id,category_id) VALUES(?,?);";
		Connection con = null;
		java.sql.PreparedStatement pps = null;
		try {
			con = DBCP.getDatasource().getConnection();
			pps = con.prepareStatement(sql);
			pps.setInt(1, uid);
			pps.setInt(2, c.getId());
			count = pps.executeUpdate();
		} catch (SQLException e) {
			System.out.println(TAG + "INSERT CAP " + e.toString());
		} finally {
			try {
				if (con != null) {
					con.close();
				}
				if (pps != null) {
					pps.close();
				}
			} catch (SQLException e) {
				System.out.println(TAG + "close " + e.toString());
			}
		}
		return count;
	}

	@Override
	public int deleteUserCapacity(int uid, Category c) {
		int count = 0;
		String sql = "DELETE FROM user_capacity WHERE user_id=? AND category_id=?;";
		Connection con = null;
		java.sql.PreparedStatement pps = null;
		try {
			con = DBCP.getDatasource().getConnection();
			pps = con.prepareStatement(sql);
			pps.setInt(1, uid);
			pps.setInt(2, c.getId());
			count = pps.executeUpdate();
		} catch (SQLException e) {
			System.out.println(TAG + "DELETE CAP " + e.toString());
		} finally {
			try {
				if (con != null) {
					con.close();
				}
				if (pps != null) {
					pps.close();
				}
			} catch (SQLException e) {
				System.out.println(TAG + "close " + e.toString());
			}
		}
		return count;
	}

	@Override
	public int insertUserTag(UserTag tag) {
		int count = 0;
		String sql = "INSERT INTO user_tag(user_id,tag_id,tag_name) VALUES(?,?,?);";
		Connection con = null;
		java.sql.PreparedStatement pps = null;
		try {
			con = DBCP.getDatasource().getConnection();
			pps = con.prepareStatement(sql);
			pps.setInt(1, tag.getUserId());
			pps.setInt(2, tag.getTagId());
			pps.setString(3, tag.getName());
			count = pps.executeUpdate();
		} catch (SQLException e) {
			System.out.println(TAG + "INSERT TAG " + e.toString());
		} finally {
			try {
				if (con != null) {
					con.close();
				}
				if (pps != null) {
					pps.close();
				}
			} catch (SQLException e) {
				System.out.println(TAG + "close " + e.toString());
			}
		}
		return count;
	}

	@Override
	public int deleteUserTag(UserTag tag) {
		int count = 0;
		String sql = "DELETE FROM user_tag WHERE user_tag_id = ?;";
		Connection con = null;
		java.sql.PreparedStatement pps = null;
		try {
			con = DBCP.getDatasource().getConnection();
			pps = con.prepareStatement(sql);
			pps.setInt(1, tag.getUserTagId());
			count = pps.executeUpdate();
		} catch (SQLException e) {
			System.out.println(TAG + "DELETE TAG " + e.toString());
		} finally {
			try {
				if (con != null) {
					con.close();
				}
				if (pps != null) {
					pps.close();
				}
			} catch (SQLException e) {
				System.out.println(TAG + "close " + e.toString());
			}
		}
		return count;
	}

	@Override
	public int createAlbum(int uid) {
		int count = 0;
		String sql = "INSERT INTO user_album(album_name,user_id,album_description) VALUES (?,?,?);";
		Connection con = null;
		java.sql.PreparedStatement pps = null;
		try {
			con = DBCP.getDatasource().getConnection();
			pps = con.prepareStatement(sql);
			pps.setString(1, "default");
			pps.setInt(2, uid);
			pps.setString(3, "default");
			count = pps.executeUpdate();
		} catch (SQLException e) {
			System.out.println(TAG + "CREATE ALBUM " + e.toString());
		} finally {
			try {
				if (con != null) {
					con.close();
				}
				if (pps != null) {
					pps.close();
				}
			} catch (SQLException e) {
				System.out.println(TAG + "close " + e.toString());
			}
		}

		return count;
	}

	@Override
	public int deleteAlbum(int aid) {
		int count = 0;
		String sql = "DELETE FROM user_album WHERE album_id = ?;";
		Connection con = null;
		java.sql.PreparedStatement pps = null;
		try {
			con = DBCP.getDatasource().getConnection();
			pps = con.prepareStatement(sql);
			pps.setInt(1, aid);
			count = pps.executeUpdate();
		} catch (SQLException e) {
			System.out.println(TAG + "DELETE ALBUM " + e.toString());
		} finally {
			try {
				if (con != null) {
					con.close();
				}
				if (pps != null) {
					pps.close();
				}
			} catch (SQLException e) {
				System.out.println(TAG + "close " + e.toString());
			}
		}

		return count;
	}

	@Override
	public int updateAlbum(Album album) {
		int count = 0;
		String sql = "UPDATE user_album SET album_name = ?,album_description = ? WHERE album_id = ?;";
		Connection con = null;
		java.sql.PreparedStatement pps = null;
		try {
			con = DBCP.getDatasource().getConnection();
			pps = con.prepareStatement(sql);
			pps.setString(1, album.getAlbumName());
			pps.setString(2, album.getAlbumDes());
			pps.setInt(3, album.getAlbumId());
			count = pps.executeUpdate();
		} catch (SQLException e) {
			System.out.println(TAG + "DELETE ALBUM " + e.toString());
		} finally {
			try {
				if (con != null) {
					con.close();
				}
				if (pps != null) {
					pps.close();
				}
			} catch (SQLException e) {
				System.out.println(TAG + "close " + e.toString());
			}
		}
		return count;
	}

	@Override
	public int uploadImgToAlbum(byte[] img, Album album) {
		int count = 0;
		String sql = "INSERT INTO album_img(album_id,img_path) VALUES(?,?);";
		Connection con = null;
		java.sql.PreparedStatement pps = null;
		FileOutputStream fo = null;
		try {
			long date = Calendar.getInstance().getTimeInMillis();
			String path = "u" + album.getUserId() + "album" + album.getAlbumId() + "img" + date;
			con = DBCP.getDatasource().getConnection();
			pps = con.prepareStatement(sql);
			pps.setInt(1, album.getAlbumId());
			pps.setString(2, path);
			count = pps.executeUpdate();
			fo = new FileOutputStream(IMG_DIR + path);
			fo.write(img);
		} catch (SQLException e) {
			System.out.println(TAG + "UPLOAD IMG " + e.toString());
		} catch (FileNotFoundException e) {
			System.out.println(TAG + "FILE NOT FOUND " + e.toString());
		} catch (IOException e) {
			System.out.println(TAG + "IMG IO " + e.toString());
		} finally {
			try {
				if (con != null) {
					con.close();
				}
				if (pps != null) {
					pps.close();
				}
			} catch (SQLException e) {
				System.out.println(TAG + "close " + e.toString());
			}
		}
		return count;
	}

	@Override
	public int deleteImg(AlbumImg img) {
		int count = 0;
		String sql = "DELETE FROM album_img WHERE img_id=?;";
		Connection con = null;
		java.sql.PreparedStatement pps = null;
		try {
			con = DBCP.getDatasource().getConnection();
			pps = con.prepareStatement(sql);
			pps.setInt(1, img.getImgId());
			count = pps.executeUpdate();
			if (count != 0) {
				String path = IMG_DIR + img.getImgPath();
				File file = new File(path);
				if (file.delete()) {
					System.out.println("IMG DELETE SUCCCESS");
				} else {
					System.err.println("IMG DELETE FAIL");
				}
			}
		} catch (SQLException e) {
			System.out.println(TAG + "DELETE IMG " + e.toString());
		} finally {
			try {
				if (con != null) {
					con.close();
				}
				if (pps != null) {
					pps.close();
				}
			} catch (SQLException e) {
				System.out.println(TAG + "close " + e.toString());
			}
		}

		return count;
	}

	@Override
	public int updateImg(AlbumImg img) {
		int count = 0;
		String sql = "UPDATE album_img SET img_name=?,img_description=? WHERE img_id=?;";
		Connection con = null;
		java.sql.PreparedStatement pps = null;
		try {
			con = DBCP.getDatasource().getConnection();
			pps = con.prepareStatement(sql);
			pps.setString(1, img.getImgName());
			pps.setString(2, img.getImgDes());
			count = pps.executeUpdate();
		} catch (SQLException e) {
			System.out.println(TAG + "UPDATE IMG " + e.toString());
		} finally {
			try {
				if (con != null) {
					con.close();
				}
				if (pps != null) {
					pps.close();
				}
			} catch (SQLException e) {
				System.out.println(TAG + "close " + e.toString());
			}
		}
		return count;
	}

	@Override
	public int rateUser(int rator, int rated, int score, String comment) {
		int count = 0;
		String sql = "INSERT INTO user_rating(from_user_id,to_user_id,rating,comment) VALUES(?,?,?,?);";
		Connection con = null;
		java.sql.PreparedStatement pps = null;
		try {
			con = DBCP.getDatasource().getConnection();
			pps = con.prepareStatement(sql);
			pps.setInt(1, rator);
			pps.setInt(2, rated);
			pps.setInt(3, score);
			pps.setString(4, comment);
			count = pps.executeUpdate();
		} catch (SQLException e) {
			System.out.println(TAG + "RATE USER " + e.toString());
		} finally {
			try {
				if (con != null) {
					con.close();
				}
				if (pps != null) {
					pps.close();
				}
			} catch (SQLException e) {
				System.out.println(TAG + "close " + e.toString());
			}
		}

		return count;
	}

	// select except password
	@Override
	public User findUserById(int uid) {
		User user = null;
		String sql = "SELECT * FROM user_account WHERE user_id = ?;";
		Connection con = null;
		java.sql.PreparedStatement pps = null;

		try {
			con = DBCP.getDatasource().getConnection();
			pps = con.prepareStatement(sql);
			pps.setInt(1, uid);
			ResultSet rs = pps.executeQuery();

			if (rs.next()) {
				int userId = rs.getInt(1);
				String email = rs.getString(2);
				// String password =rs.getString(3);//skipped
				Date registerTime = rs.getDate(4);
				boolean isFBRegistered = rs.getBoolean(5);
				String userName = rs.getString(6);
				String userLINE = rs.getString(7);
				String userSelfDes = rs.getString(8);
				boolean userGender = rs.getBoolean(9);
				String userPicPath = rs.getString(10);
				String userlive =rs.getString(11);

				user = new User(userId, email, registerTime, isFBRegistered, userName, userLINE, userSelfDes,
						userGender, userPicPath,userlive);
			}
		} catch (SQLException e) {
			System.out.println(TAG + "FIND USER BY ID " + e.toString());
		} finally {
			try {
				if (con != null) {
					con.close();
				}
				if (pps != null) {
					pps.close();
				}
			} catch (SQLException e) {
				System.out.println(TAG + "close " + e.toString());
			}
		}
		return user;
	}

	@Override
	public UserCompany getCompanyByUId(int uid) {
		UserCompany uc = null;
		String sql = "SELECT user_company.user_company_id , user_company.user_id , company.* "
				+ "FROM user_company LEFT JOIN company ON user_company.company_id = company.company_id WHERE user_id=?;";
		Connection con = null;
		java.sql.PreparedStatement pps = null;
		try {
			con = DBCP.getDatasource().getConnection();
			pps = con.prepareStatement(sql);
			pps.setInt(1, uid);
			ResultSet rs = pps.executeQuery();
			if (rs.next()) {
				int userCompanyId = rs.getInt(1);
				int userId = rs.getInt(2);
				int companyId = rs.getInt(3);
				final int uniformNumber = rs.getInt(4);
				String companyName = rs.getString(5);
				double latitude = rs.getDouble(6);
				double longitude = rs.getDouble(7);

				uc = new UserCompany(userCompanyId, userId, companyId, uniformNumber, companyName, latitude, longitude);
			}
		} catch (SQLException e) {
			System.out.println(TAG + "FIND COMPANY BY UID " + e.toString());
		} finally {
			try {
				if (con != null) {
					con.close();
				}
				if (pps != null) {
					pps.close();
				}
			} catch (SQLException e) {
				System.out.println(TAG + "close " + e.toString());
			}
		}

		return uc;
	}

	@Override
	public List<User> findAll() {
		List<User> users = new ArrayList<>();
		String sql = "SELECT user_id,email,register_time,facebook_registered,user_name,user_LINE,user_self_description,user_gender,user_pic_path "
				+ "FROM user_account";
		Connection con = null;
		java.sql.PreparedStatement pps = null;
		try {
			con = DBCP.getDatasource().getConnection();
			pps = con.prepareStatement(sql);
			ResultSet rs = pps.executeQuery();
			while (rs.next()) {
				int userId = rs.getInt(1);
				String email = rs.getString(2);
				Date registerTime = rs.getDate(3);
				boolean isFBRegistered = rs.getBoolean(4);
				String userName = rs.getString(5);
				String userLINE = rs.getString(6);
				String userSelfDes = rs.getString(7);
				boolean userGender = rs.getBoolean(8);
				String userPicPath = rs.getString(9);

				User user = new User(userId, email, registerTime, isFBRegistered, userName, userLINE, userSelfDes,
						userGender, userPicPath);
				users.add(user);
			}
		} catch (SQLException e) {
			System.out.println(TAG + "FIND ALL " + e.toString());
		} finally {
			try {
				if (con != null) {
					con.close();
				}
				if (pps != null) {
					pps.close();
				}
			} catch (SQLException e) {
				System.out.println(TAG + "close " + e.toString());
			}
		}
		return users;
	}

	@Override
	public List<User> findAllByCategory(Category c) {
		List<User> users = new ArrayList<>();
		String sql = "SELECT user_account.*"
				+ "FROM user_capacity LEFT JOIN user_account ON user_capacity.user_id=user_account.user_id "
				+ "WHERE category_id = ?";
		Connection con = null;
		java.sql.PreparedStatement pps = null;
		try {
			con = DBCP.getDatasource().getConnection();
			pps = con.prepareStatement(sql);
			pps.setInt(1, c.getId());
			ResultSet rs = pps.executeQuery();
			while (rs.next()) {
				int userId = rs.getInt(1);
				String email = rs.getString(2);
				// String password =rs.getString(3);//skipped
				Date registerTime = rs.getDate(4);
				boolean isFBRegistered = rs.getBoolean(5);
				String userName = rs.getString(6);
				String userLINE = rs.getString(7);
				String userSelfDes = rs.getString(8);
				boolean userGender = rs.getBoolean(9);
				String userPicPath = rs.getString(10);

				User user = new User(userId, email, registerTime, isFBRegistered, userName, userLINE, userSelfDes,
						userGender, userPicPath);
				users.add(user);
			}
		} catch (SQLException e) {
			System.out.println(TAG + "FIND ALL BY CATEGORY " + e.toString());
		} finally {
			try {
				if (con != null) {
					con.close();
				}
				if (pps != null) {
					pps.close();
				}
			} catch (SQLException e) {
				System.out.println(TAG + "close " + e.toString());
			}
		}
		return users;
	}

	@Override
	public List<User> findAllByCompany(UserCompany uc) {
		List<User> users = new ArrayList<>();
		String sql = "SELECT user_account.* FROM user_account RIGHT JOIN user_company ON user_account.user_id = user_company.user_id WHERE company_id = ? ;";
		Connection con = null;
		java.sql.PreparedStatement pps = null;
		try {
			con = DBCP.getDatasource().getConnection();
			pps = con.prepareStatement(sql);
			pps.setInt(1, uc.getCompanyId());
			ResultSet rs = pps.executeQuery();
			while (rs.next()) {
				int userId = rs.getInt(1);
				String email = rs.getString(2);
				// String password =rs.getString(3);//skipped
				Date registerTime = rs.getDate(4);
				boolean isFBRegistered = rs.getBoolean(5);
				String userName = rs.getString(6);
				String userLINE = rs.getString(7);
				String userSelfDes = rs.getString(8);
				boolean userGender = rs.getBoolean(9);
				String userPicPath = rs.getString(10);

				User user = new User(userId, email, registerTime, isFBRegistered, userName, userLINE, userSelfDes,
						userGender, userPicPath);
				users.add(user);
			}
		} catch (SQLException e) {
			System.out.println(TAG + "FIND ALL BY COMPANY " + e.toString());
		} finally {
			try {
				if (con != null) {
					con.close();
				}
				if (pps != null) {
					pps.close();
				}
			} catch (SQLException e) {
				System.out.println(TAG + "close " + e.toString());
			}
		}

		return users;
	}

	@Override
	public List<Album> findAllAlbumByUId(int uid) {
		List<Album> albums = new ArrayList<>();
		String sql = "SELECT * FROM user_album WHERE user_id=?;";
		Connection con = null;
		java.sql.PreparedStatement pps = null;
		try {
			con = DBCP.getDatasource().getConnection();
			pps = con.prepareStatement(sql);
			pps.setInt(1, uid);
			ResultSet rs = pps.executeQuery();
			while (rs.next()) {
				int albumId = rs.getInt(1);
				String albumName = rs.getString(2);
				int userId = rs.getInt(3);
				Date createDate = rs.getDate(4);
				Date updateDate = rs.getDate(5);
				String albumDes = rs.getString(6);

				Album album = new Album(albumId, albumName, userId, createDate, updateDate, albumDes);
				albums.add(album);
			}
		} catch (SQLException e) {
			System.out.println(TAG + "FIND ALBUM BY USER" + e.toString());
		} finally {
			try {
				if (con != null) {
					con.close();
				}
				if (pps != null) {
					pps.close();
				}
			} catch (SQLException e) {
				System.out.println(TAG + "close " + e.toString());
			}
		}
		return albums;
	}

	@Override
	public List<UserTag> findTagsByUId(int uid) {
		List<UserTag> tags = new ArrayList<>();
		String sql = "SELECT user_tag.*,tag.category_id " + "FROM "
				+ "user_tag LEFT JOIN tag ON user_tag.tag_id = tag.tag_id WHERE user_tag.user_id = ?;";
		Connection con = null;
		java.sql.PreparedStatement pps = null;
		try {
			con = DBCP.getDatasource().getConnection();
			pps = con.prepareStatement(sql);
			pps.setInt(1, uid);
			ResultSet rs = pps.executeQuery();
			while (rs.next()) {
				int userTagId = rs.getInt(1);
				int userId = rs.getInt(2);
				int tagId = rs.getInt(3);
				String tagName = rs.getString(4);
				int categoryId = rs.getInt(5);

				UserTag tag = new UserTag(userTagId, userId, tagId, tagName, Category.getCategoryById(categoryId));
				tags.add(tag);
			}
		} catch (SQLException e) {
			System.out.println(TAG + "FIND TAG BY USER" + e.toString());
		} finally {
			try {
				if (con != null) {
					con.close();
				}
				if (pps != null) {
					pps.close();
				}
			} catch (SQLException e) {
				System.out.println(TAG + "close " + e.toString());
			}
		}

		return tags;
	}

	@Override
	public List<UserCapacity> findCapacitiesByUId(int uid) {
		List<UserCapacity> capacities = new ArrayList<>();
		String sql = "SELECT * FROM user_capacity WHERE user_id = ?;";
		Connection con = null;
		java.sql.PreparedStatement pps = null;
		try {
			con = DBCP.getDatasource().getConnection();
			pps = con.prepareStatement(sql);
			pps.setInt(1, uid);
			ResultSet rs = pps.executeQuery();
			while (rs.next()) {
				int userCapacityId = rs.getInt(1);
				int userId = rs.getInt(2);
				int categoryId = rs.getInt(3);
				UserCapacity ucp = new UserCapacity(userCapacityId, userId, Category.getCategoryById(categoryId));
				capacities.add(ucp);
			}
		} catch (SQLException e) {
			System.out.println(TAG + "FIND CAPACITY BY USER" + e.toString());
		} finally {
			try {
				if (con != null) {
					con.close();
				}
				if (pps != null) {
					pps.close();
				}
			} catch (SQLException e) {
				System.out.println(TAG + "close " + e.toString());
			}
		}
		return capacities;
	}

	@Override
	public List<UserExp> findExpsByUId(int uid) {
		List<UserExp> exps = new ArrayList<>();
		String sql = "SELECT * FROM user_experience WHERE user_id = ?;";
		Connection con = null;
		java.sql.PreparedStatement pps = null;
		try {
			con = DBCP.getDatasource().getConnection();
			pps = con.prepareStatement(sql);
			pps.setInt(1, uid);
			ResultSet rs = pps.executeQuery();
			while (rs.next()) {
				int expId = rs.getInt(1);
				int userId = rs.getInt(2);
				String expDes = rs.getString(3);
				Date lastEditTime = rs.getDate(4);
				Date startDate = rs.getDate(5);
				Date endDate = rs.getDate(6);

				UserExp exp = new UserExp(expId, userId, expDes, lastEditTime, startDate, endDate);
				exps.add(exp);
			}
		} catch (SQLException e) {
			System.out.println(TAG + "FIND EXP BY USER" + e.toString());
		} finally {
			try {
				if (con != null) {
					con.close();
				}
				if (pps != null) {
					pps.close();
				}
			} catch (SQLException e) {
				System.out.println(TAG + "close " + e.toString());
			}
		}
		return exps;
	}

	// only info no img src
	@Override
	public List<AlbumImg> findAllImgByAlbum(int aid) {
		List<AlbumImg> imgs = new ArrayList<>();
		String sql = "SELECT * FROM album_img WHERE album_id = ?;";
		Connection con = null;
		java.sql.PreparedStatement pps = null;
		try {
			con = DBCP.getDatasource().getConnection();
			pps = con.prepareStatement(sql);
			pps.setInt(1, aid);
			ResultSet rs = pps.executeQuery();
			while (rs.next()) {
				int imgId = rs.getInt(1);
				int albumId = rs.getInt(2);
				String imgName = rs.getString(3);
				String imgPath = rs.getString(4);
				Date imgCreateDate = rs.getDate(5);
				Date imgLastEditDate = rs.getDate(6);
				String imgDes = rs.getString(7);
				AlbumImg img = new AlbumImg(imgId, albumId, imgName, imgPath, imgCreateDate, imgLastEditDate, imgDes);
				imgs.add(img);
			}
		} catch (SQLException e) {
			System.out.println(TAG + "FIND IMG BY ALBUM" + e.toString());
		} finally {
			try {
				if (con != null) {
					con.close();
				}
				if (pps != null) {
					pps.close();
				}
			} catch (SQLException e) {
				System.out.println(TAG + "close " + e.toString());
			}
		}

		return imgs;
	}

	// get real img src
	@Override
	public byte[] getImgByPath(String path) {
		byte[] img = null;
		try {
			img = Files.readAllBytes(new File(IMG_DIR + path).toPath());
		} catch (IOException e) {
			System.out.println(TAG + "GET IMG BY PATH" + e.toString());
		}
		return img;

	}

	// search users by name,company name,tag name in certain category
	@Override
	public List<User> searchUsersByWord(String word, Category c) {

		String keyword = keywordFactory(word);
		List<User> users = new ArrayList<>();
		String sql = "SELECT user_account.* FROM user_account RIGHT JOIN user_capacity ON user_account.user_id = user_capacity.user_id "
				+ "RIGHT JOIN user_tag ON user_capacity.user_id = user_tag.user_id RIGHT JOIN user_company ON user_tag.user_id=user_company.user_id"
				+ "WHERE LOWER(user_name) LIKE ? OR LOWER(company_name) LIKE ? OR LOWER(tag_anme) LIKE ?;";
		Connection con = null;
		java.sql.PreparedStatement pps = null;

		try {
			con = DBCP.getDatasource().getConnection();
			pps = con.prepareStatement(sql);
			pps.setString(1, keyword);
			pps.setString(2, keyword);
			pps.setString(3, keyword);
			ResultSet rs = pps.executeQuery();
			while (rs.next()) {
				int userId = rs.getInt(1);
				String email = rs.getString(2);
				// String password =rs.getString(3);//skipped
				Date registerTime = rs.getDate(4);
				boolean isFBRegistered = rs.getBoolean(5);
				String userName = rs.getString(6);
				String userLINE = rs.getString(7);
				String userSelfDes = rs.getString(8);
				boolean userGender = rs.getBoolean(9);
				String userPicPath = rs.getString(10);

				User user = new User(userId, email, registerTime, isFBRegistered, userName, userLINE, userSelfDes,
						userGender, userPicPath);
				users.add(user);

			}
		} catch (SQLException e) {
			System.out.println(TAG + "SEARCH BY WORD" + e.toString());
		} finally {
			try {
				if (con != null) {
					con.close();
				}
				if (pps != null) {
					pps.close();
				}
			} catch (SQLException e) {
				System.out.println(TAG + "close " + e.toString());
			}
		}

		return users;
	}

	// LIKE-Search lower-cased keyword generate(ex:WorD to w%o%r%d%)
	private String keywordFactory(String word) {

		char[] charArray = word.toCharArray();
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < charArray.length; i++) {
			sb.append(charArray[i] + "%");
		}
		String keyword = sb.toString();
		System.out.println("SEARCH : " + keyword);// TEST

		return keyword;
	}

	@Override
	public String findUserPhone(int uid) {
		
		String sql = "SELECT  user_phone_number FROM user_phone WHERE user_id = ?;";
		Connection con = null;
		java.sql.PreparedStatement pps = null;
        String phoneNumber = "";
		try {
			con = DBCP.getDatasource().getConnection();
			pps = con.prepareStatement(sql);
			pps.setInt(1, uid);
			ResultSet rs = pps.executeQuery();
             
			if (rs.next()) {
				  phoneNumber = rs.getString(1);
				 
			}
		} catch (SQLException e) {
			System.out.println(TAG + "FIND USER BY ID " + e.toString());
		} finally {
			try {
				if (con != null) {
					con.close();
				}
				if (pps != null) {
					pps.close();
				}
			} catch (SQLException e) {
				System.out.println(TAG + "close " + e.toString());
			}
		}
		
		return  phoneNumber;
	}

	@Override
	public int updateUserPhone(int uid,String phoneNumber) {
		String sql = "UPDATE user_phone SET user_phone_number = ? WHERE user_id = ?;";
		Connection conn = null;
		PreparedStatement ps = null;
		int count = 0;
		try {
			conn = DriverManager.getConnection(Common.URL, Common.USER,
					Common.PASSWORD);
			ps = conn.prepareStatement(sql);
			ps.setString(1, phoneNumber);
			ps.setInt(2, uid);
			count = ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return count;
		
	}
	
	
}
