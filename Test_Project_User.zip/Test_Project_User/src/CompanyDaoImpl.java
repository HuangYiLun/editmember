


import java.io.BufferedReader;
import java.io.IOException;

import java.io.InputStreamReader;

import java.net.URL;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

public class CompanyDaoImpl implements ICompanyDao {

	private static final String TAG = "CompanyDaoImpl : ";
	private static final String UN_URL = "http://data.gcis.nat.gov.tw/od/data/api"
			+ "/5F64D864-61CB-4D0D-8AD9-492047CC1EA6?$format=json&$filter=Business_Accounting_NO%20eq%" + "20";
	private static final String API_KEY = "&key=AIzaSyBZlit2oi2GAswrFzj2F7skM5b4Xgf0hsk";
	private static final String GEO_URL = "https://maps.googleapis.com/maps/api/geocode/json?address=";
	
	private static CompanyDaoImpl instance =new CompanyDaoImpl();
	
	public static CompanyDaoImpl getInstance() {
		return instance;
	}

	@Override
	public int insertCompany(int UN) {
		int count = 0;
		Company company = searchCompany(UN);
		String sql = "INSERT INTO company(UN,company_name,latitude,longitude) VALUES(?,?,?,?);";
		Connection con = null;
		java.sql.PreparedStatement pps = null;

		try {
			con = DBCP.getDatasource().getConnection();
			pps = con.prepareStatement(sql,PreparedStatement.RETURN_GENERATED_KEYS);
			pps.setInt(1, UN);
			pps.setString(2, company.getName());
			pps.setDouble(3, company.getLatitude());
			pps.setDouble(4, company.getLongitude());
		   pps.executeUpdate();
		   ResultSet rs= pps.getGeneratedKeys();
		   if (rs.next()) {
			count = rs.getInt(1);
		}
		} catch (SQLException e) {
			System.out.println(TAG + "INSERT COMPANY" + e.toString());
		} finally {
			try {
				if (con != null) {
					con.close();
				}
				if (pps != null) {
					pps.close();
				}
			} catch (SQLException e) {
				System.out.println(TAG + "close " + e.toString());
			}
		}
		return count;
	}

	@Override
	public Company searchCompany(int UN) {
		URL url = null;
		BufferedReader br = null;
		Company company = null;
		try {
			url = new URL(UN_URL + String.valueOf(UN));
			br = new BufferedReader(new InputStreamReader(url.openStream()));
			String line;
			StringBuilder sb1 = new StringBuilder();
			while ((line = br.readLine()) != null) {
				sb1.append(line);
			}
			System.out.println("GOV API IN : " + sb1.toString());
			if (sb1.toString().trim() != null && sb1.toString().trim().length() != 0) {
				JsonArray jsonArray = new Gson().fromJson(sb1.toString(), JsonArray.class);
				String name = jsonArray.get(0).getAsJsonObject().get("Company_Name").getAsString();
				String address = jsonArray.get(0).getAsJsonObject().get("Company_Location").getAsString();
				URL gurl = new URL(GEO_URL + address + API_KEY);
				br = new BufferedReader(new InputStreamReader(gurl.openStream()));
				StringBuilder sb2 = new StringBuilder();
				String ch;
				while ((ch = br.readLine()) != null) {
					sb2.append(ch);
				}
				String gInput = sb2.toString();
				JsonObject jo = new Gson().fromJson(gInput, JsonObject.class);
				System.out.println("GOOGLE MAP " + jo.toString());
				double lat = jo.get("results").getAsJsonArray().get(0).getAsJsonObject().get("geometry")
						.getAsJsonObject().get("location").getAsJsonObject().get("lat").getAsDouble();
				double lng = jo.get("results").getAsJsonArray().get(0).getAsJsonObject().get("geometry")
						.getAsJsonObject().get("location").getAsJsonObject().get("lng").getAsDouble();
				System.out.println("GOV API RETRIEVED :" + name + "," + address);

				System.out.println("GOOGLE MAP " + lat + "," + lng);

				company = new Company(-1, UN, name, lat, lng);
			}
		} catch (IOException e) {
			System.out.println("search Company : " + e.toString());
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					System.out.println("close : " + e.toString());
				}
			}
		}
		return company;
	}

	@Override
	public Company searchCompanyByUN(int UN) {
		Company company = null;
		String sql = "SELECT * FROM company WHERE UN = ?;";
		Connection con = null;
		java.sql.PreparedStatement pps = null;

		try {
			con = DBCP.getDatasource().getConnection();
			pps = con.prepareStatement(sql);
			pps.setInt(1, UN);
			ResultSet rs = pps.executeQuery();

			if (rs.next()) {
				int companyId = rs.getInt(1);
				int un = rs.getInt(2);
				// String password =rs.getString(3);//skipp
				String name = rs.getString(3);
				double latitude = rs.getInt(4);
				double longitude = rs.getInt(5);
				

				company = new Company(companyId, un, name, latitude, longitude);
			}
		} catch (SQLException e) {
			System.out.println(TAG + "FIND USER BY ID " + e.toString());
		} finally {
			try {
				if (con != null) {
					con.close();
				}
				if (pps != null) {
					pps.close();
				}
			} catch (SQLException e) {
				System.out.println(TAG + "close " + e.toString());
			}
		}
		return company;
		
	}

}
