
public class Common {
	public final static String URL = "jdbc:mysql://localhost:8889/show2";
	public final static String USER = "root";
	public final static String PASSWORD = "root";

}
