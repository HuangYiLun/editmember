

public interface UserDao {
	
	
	User userExist(String email, String password);
	
	int insert(User user);

	int update(User user);
	
	boolean userEmailExist(String email);


	User findByEM(String email);



}
