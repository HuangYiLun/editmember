import java.util.List;

public interface IUserDao {

	// if format-check success,insert a column into table
//	int register(String email, String password);
	int register(User user);

	// if email and password are both correct,return a User obj
	User login(String email, String password);

	// update info
	int update(User u);

	// IO
	int UpdateUserPic(byte[] pic, String path);
	//get user real pic
	byte[] getUserPicByPath(String path);
	//
	int updateCompany(UserCompany uc);

	int insertUserCapacity(int uid, Category c);

	int deleteUserCapacity(int uid, Category c);

	int insertUserTag(UserTag tag);

	int deleteUserTag(UserTag tag);

	// establish album;
	int createAlbum(int uid);

	int deleteAlbum(int aid);

	int updateAlbum(Album album);

	// album img operations
	int uploadImgToAlbum(byte[] img, Album album);

	int deleteImg(AlbumImg img);

	int updateImg(AlbumImg img);

	int rateUser(int rator, int rated,int score,String comment);

	User findUserById(int imgId);
	
	String findUserPhone(int uid);
	
	int  updateUserPhone(int uid,String phonenumber);

	// get real img
	byte[] getImgByPath(String path);

	UserCompany getCompanyByUId(int uid);

	List<User> findAll();

	List<User> findAllByCategory(Category c);

	List<User> findAllByCompany(UserCompany uc);

	// get all cases target user involved

	List<Album> findAllAlbumByUId(int uid);

	List<UserTag> findTagsByUId(int uid);

	List<UserCapacity> findCapacitiesByUId(int uid);

	List<UserExp> findExpsByUId(int uid);

	// get ONLY img info
	List<AlbumImg> findAllImgByAlbum(int aid);

	// User name,user capacity tag in Category
	List<User> searchUsersByWord(String word, Category c);

}
